package com.example.paul.constants;

public enum ACTION {
    DEPOSIT,
    WITHDRAW
}
